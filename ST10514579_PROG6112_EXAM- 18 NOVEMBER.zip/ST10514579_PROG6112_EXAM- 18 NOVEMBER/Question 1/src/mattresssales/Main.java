package mattresssales;

class Product implements mattresssales.IProduct {

    private final String[] productNames;   // 1D array
    private final int[][] sales;           // 2D array [product][month]

    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int p = 0; p < sales.length; p++) {
            for (int m = 0; m < sales[p].length; m++) {
                total += sales[p][m];
            }
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int count = 0;
        for (int p = 0; p < sales.length; p++) {
            count += sales[p].length;
        }
        if (count == 0) {
            return 0;
        }
        return (double) GetTotalProductsSold() / count;
    }

    @Override
    public String GetMostPopularProduct() {
        int highest = Integer.MIN_VALUE;
        int highestIndex = -1;

        for (int p = 0; p < sales.length; p++) {
            for (int m = 0; m < sales[p].length; m++) {
                if (sales[p][m] > highest) {
                    highest = sales[p][m];
                    highestIndex = p;
                }
            }
        }

        if (highestIndex == -1) {
            return "No sales data";
        }
        return productNames[highestIndex] + " (" + highest + ")";
    }
}
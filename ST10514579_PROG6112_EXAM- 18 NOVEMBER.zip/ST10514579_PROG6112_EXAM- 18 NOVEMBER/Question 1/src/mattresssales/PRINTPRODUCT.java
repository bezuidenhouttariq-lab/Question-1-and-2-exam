package mattresssales;

class PrintProduct {

    private final mattresssales.IProduct product;

    public PrintProduct(mattresssales.IProduct product) {
        this.product = product;
    }

    public void printHeader() {
        System.out.println("\n\nPRODUCT SALES REPORT - 2026");
        System.out.println("**********************************************");
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        System.out.println("AVERAGE PRODUCT SALES:  " + Math.round(product.GetAverageProductSold()));
    }

    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
package productapp;

public interface IProductCalculations {
}

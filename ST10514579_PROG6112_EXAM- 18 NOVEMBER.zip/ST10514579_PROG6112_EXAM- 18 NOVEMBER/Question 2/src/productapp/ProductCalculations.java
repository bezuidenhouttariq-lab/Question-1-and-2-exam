package productapp;

public class ProductCalculations implements IProductCalculations {

    private static final double VAT_RATE = 0.15;
    private static final double COMMISSION_RATE = 0.05;

    private final double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    public double GetVat() {
        return price * VAT_RATE;
    }

    public double GetCommission() {
        return price * COMMISSION_RATE;
    }

    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}